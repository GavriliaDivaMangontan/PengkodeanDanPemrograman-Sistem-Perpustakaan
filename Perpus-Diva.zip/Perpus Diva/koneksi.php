<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "db_perpustakaan";

$connect = mysqli_connect($host,$username,$password,$db);
?>